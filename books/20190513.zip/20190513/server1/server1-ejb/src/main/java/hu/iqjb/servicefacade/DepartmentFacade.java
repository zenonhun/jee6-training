/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.servicefacade;

import hu.iqjb.domain.model.Department;
import hu.iqjb.exception.MyException;
import hu.iqjb.interceptor.ExecutionTimeInterceptor;
import hu.iqjb.sessionservice.DepartmentService;
import hu.iqjb.sessionservice.DepartmentService2;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.TimedObject;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.interceptor.Interceptors;

/**
 *
 * @author avincze
 */
@Stateless
@LocalBean
//@Interceptors(ExecutionTimeInterceptor.class)
public class DepartmentFacade {

    @EJB
    private DepartmentService departmentService;

    @EJB
    private DepartmentService2 departmentService2;

    @Resource
    private SessionContext sessionContext;
    
 
    
    
    //@Interceptors(ExecutionTimeInterceptor.class)
    public void add(Department department) {
        try {
            departmentService.add(department);
            departmentService2.add(department);
            
            sessionContext.getTimerService().createTimer(3000, department);
        } catch (MyException ex) {
            //sessionContext.setRollbackOnly();
            Logger.getLogger(DepartmentFacade.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    public List<Department> getAll() {
        System.out.println(sessionContext.getCallerPrincipal().getName());
        List<Department> result = new ArrayList<>();
        result.addAll(departmentService.getAll());
        result.addAll(departmentService2.getAll());
        
        return result;
    }

    
    
    
    @Timeout
    public void ejbTimeout2(Timer timer) {
        Department department = (Department) timer.getInfo();
        System.out.println(department.getName());
        timer.cancel();
        
   }
    
    
}
