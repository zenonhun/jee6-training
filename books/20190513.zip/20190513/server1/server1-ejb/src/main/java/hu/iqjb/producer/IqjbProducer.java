/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.producer;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author avincze
 */
public class IqjbProducer {

    @Produces
    @PersistenceContext(unitName = "server1PU")
    @Iqjb1Database
    private EntityManager em;
    
    
    @Produces
    @PersistenceContext(unitName = "server2PU")
    @Iqjb2Database
    private EntityManager em2;

}
