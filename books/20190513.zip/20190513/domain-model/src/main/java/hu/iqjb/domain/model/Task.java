/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.domain.model;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author avincze
 */
@Entity
@Table(name = "Task")
public class Task extends IqjbEntity{

    private String name;
    
    @ManyToOne
    @JoinColumn(name = "employeeId", referencedColumnName = "id")
    private Employee participant;

    public Employee getParticipant() {
        return participant;
    }

    public void setParticipant(Employee participant) {
        this.participant = participant;
    }
  
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    @Override
    public String toString() {
        return "hu.iqjb.domain.model.Task[ id=" + id + " ]";
    }
    
}
