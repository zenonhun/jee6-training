/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.controller;

import java.io.Serializable;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author avincze
 */

@Named
@RequestScoped
public class IntroController implements Serializable{
    
    private String name;

    public IntroController() {
        System.out.println("constructor is called");
        this.name = "hello world";
    }
    
    public void click(){
        System.out.println(name);
    }
    
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
}
