/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.jse.client;

import hu.iqjb.IqjbLogServiceRemote;
import hu.iqjb.domain.model.IqjbLog;
import hu.iqjb.remote.intf.DepartmentServiceRemoteInterface;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author avincze
 */
public class Main {
    
    public static void main(String[] args) {
        try {
            Context jndi = new InitialContext();
            IqjbLogServiceRemote intf =
            (IqjbLogServiceRemote) 
                    jndi.lookup("java:global/server2-ear/server2-ejb-1.0-SNAPSHOT/IqjbLogService!hu.iqjb.IqjbLogServiceRemote");
            IqjbLog log = new IqjbLog();
            log.setCreated(new Date());
            intf.add(log);
        
        } catch (NamingException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
