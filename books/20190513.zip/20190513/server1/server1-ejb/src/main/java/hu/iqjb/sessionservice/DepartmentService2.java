/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.sessionservice;

import hu.iqjb.domain.model.Department;
import hu.iqjb.exception.MyException;
import hu.iqjb.interceptor.ExecutionTimeInterceptor;
import hu.iqjb.remote.intf.DepartmentServiceRemoteInterface;
import hu.iqjb.repository.DepartmentRepository;
import hu.iqjb.repository.DepartmentRepository2;
import java.util.List;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;

/**
 *
 * @author avincze
 */
@Stateless
@LocalBean
@Interceptors(ExecutionTimeInterceptor.class)
public class DepartmentService2  {

    @EJB
    private DepartmentRepository2 departmentRepository;

    @Resource
    private SessionContext sessionContext;
    
    public void add(Department department) throws MyException{
        departmentRepository.add(department);
        //sessionContext.setRollbackOnly();        
    }

    public List<Department> getAll() {
        return departmentRepository.getAll();
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
