/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.controller;

import java.io.Serializable;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author avincze
 */
@Named
@ViewScoped
public class FirstPrimeController implements Serializable{
    private String firstName;
    private String lastName;
    private String loginName;

    public void pressMe(){
        System.out.println(firstName+ " " + lastName + " " + loginName);
        this.lastName = this.firstName;
        this.loginName = this.firstName;
    }
    
    public String navigate(){
        return "intro.jsf";
    }
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }
    
    
}
