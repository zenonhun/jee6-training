/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.jms;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 *
 * @author avincze
 */
@MessageDriven(mappedName = "jms/iqjb", activationConfig = {
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue")
})
public class IqjbTimeReader implements MessageListener {

    private static final Logger LOG = Logger.getLogger(IqjbTimeReader.class.getName());
    
    public IqjbTimeReader() {
    }
    
  
    @Override
    public void onMessage(Message message) {
        try {
            TextMessage textMessage = (TextMessage) message;
            LOG.info("Received message: " + textMessage.getText());
        } catch (JMSException ex) {
            Logger.getLogger(IqjbTimeReader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
