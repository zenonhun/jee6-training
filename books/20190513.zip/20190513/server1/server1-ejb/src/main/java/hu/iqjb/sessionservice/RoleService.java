/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.sessionservice;

import hu.iqjb.domain.model.Role;
import hu.iqjb.repository.RoleRepository;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.transaction.Transactional;

/**
 *
 * @author avincze
 */
@Stateless
@LocalBean
public class RoleService {
    
    @Inject
    private RoleRepository roleRepository;
    
    public void add(Role role){
        roleRepository.add(role);
    }
}
