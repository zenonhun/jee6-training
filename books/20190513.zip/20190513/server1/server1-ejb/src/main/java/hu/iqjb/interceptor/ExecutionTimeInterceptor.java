/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.interceptor;

import hu.iqjb.IqjbLogServiceRemote;
import hu.iqjb.domain.model.IqjbLog;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author avincze
 */
public class ExecutionTimeInterceptor {

    //IqjbLogServiceRemote iqjbLogService = lookupIqjbLogServiceRemote();

    
    
    @EJB(lookup = "hu.iqjb.IqjbLogServiceRemote")
    private IqjbLogServiceRemote iqjbLogService;
    
    @AroundInvoke
    public Object logExecutionTime(InvocationContext ic) throws Exception{
        Date started = new Date();
        Object result = ic.proceed();
        Date finished = new Date();
        IqjbLog iqjbLog = new IqjbLog();
        iqjbLog.setCreated(new Date());
        iqjbLog.setExecutionTime(finished.getTime() - started.getTime() + " ms");
        iqjbLog.setLogMessage(ic.getMethod() + " is called.");
        iqjbLogService.add(iqjbLog);
        return result;
    }

    private IqjbLogServiceRemote lookupIqjbLogServiceRemote() {
        try {
            Context c = new InitialContext();
            return (IqjbLogServiceRemote) c.lookup("java:global/server2-ear/server2-ejb-1.0-SNAPSHOT/IqjbLogService!hu.iqjb.IqjbLogServiceRemote");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    
    
    
    
    
}
