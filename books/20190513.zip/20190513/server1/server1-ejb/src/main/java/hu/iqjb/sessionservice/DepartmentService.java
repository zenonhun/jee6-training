/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.sessionservice;

import hu.iqjb.domain.model.Department;
import hu.iqjb.interceptor.ExecutionTimeInterceptor;
import hu.iqjb.remote.intf.DepartmentServiceRemoteInterface;
import hu.iqjb.repository.DepartmentRepository;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.interceptor.Interceptors;

/**
 *
 * @author avincze
 */
@Stateless
@LocalBean
@TransactionManagement(TransactionManagementType.CONTAINER)
@Interceptors(ExecutionTimeInterceptor.class)
public class DepartmentService implements DepartmentServiceRemoteInterface {

    @EJB
    private DepartmentRepository departmentRepository;

    @Override
    @TransactionAttribute()
    public void add(Department department) {
        departmentRepository.add(department);
    }

    @Override
    public List<Department> getAll() {
        return departmentRepository.getAll();
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
