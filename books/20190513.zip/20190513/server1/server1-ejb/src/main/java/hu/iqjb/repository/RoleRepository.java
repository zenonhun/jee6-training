/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.repository;

import hu.iqjb.domain.model.Role;
import hu.iqjb.producer.Iqjb1Database;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.TransactionScoped;
import javax.transaction.Transactional;

/**
 *
 * @author avincze
 */
@Transactional
public class RoleRepository {

    @Inject
    @Iqjb1Database
    EntityManager em;
    
    @Transactional
    public void add(Role role){
        em.persist(role);
    }

}
