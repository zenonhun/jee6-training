/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.service;

import hu.iqjb.IqjbLogServiceRemote;
import hu.iqjb.domain.model.IqjbLog;
import hu.iqjb.repository.IqjbLogRepository;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TimedObject;
import javax.ejb.Timer;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

/**
 *
 * @author avincze
 */
@Stateless
@LocalBean
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class IqjbLogService implements IqjbLogServiceRemote , TimedObject {

    @EJB
    private IqjbLogRepository repository;
    
    @Override
    public void add(IqjbLog entity) {
        repository.add(entity);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public void ejbTimeout(Timer timer) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
