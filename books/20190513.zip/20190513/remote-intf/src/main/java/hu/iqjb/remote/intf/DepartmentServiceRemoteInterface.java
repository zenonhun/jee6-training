/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.remote.intf;

import hu.iqjb.domain.model.Department;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author avincze
 */
@Remote
public interface DepartmentServiceRemoteInterface {
    void add(Department department);
    List<Department> getAll();
}