/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.repository;

import hu.iqjb.domain.model.Department;
import hu.iqjb.domain.model.IqjbLog;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author avincze
 */
@Stateless
@LocalBean
public class IqjbLogRepository {
    
    @PersistenceContext(unitName = "server3PU")
    private EntityManager em;
   
    
    public void add(IqjbLog entity){
        em.persist(entity);
    }

}
