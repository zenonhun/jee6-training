
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.db.creator;

import hu.iqjb.domain.model.Address;
import hu.iqjb.domain.model.Department;
import hu.iqjb.domain.model.Employee;
import hu.iqjb.domain.model.Project;
import hu.iqjb.domain.model.Role;
import hu.iqjb.domain.model.Task;
import java.util.Date;
import java.util.HashSet;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author avincze
 */
public class Main {

    private static EntityManagerFactory factory
            = Persistence.createEntityManagerFactory("iqjbPU");
    
    private static EntityManagerFactory factory2
            = Persistence.createEntityManagerFactory("iqjb2PU");
    
    private static EntityManagerFactory factory3
            = Persistence.createEntityManagerFactory("iqjbLogPU");

    public static void main(String[] args) {
        createDepartment(factory);
        createRole(factory);
        createEmployee(factory);
        createProject(factory);
        
        
        createDepartment(factory2);
        createRole(factory2);
        createEmployee(factory2);
        createProject(factory2);

    }

    private static void createEmployee(EntityManagerFactory factory) {
        EntityManager em = factory.createEntityManager();

        em.getTransaction().begin();
        Employee employee = new Employee();
        employee.setLoginName("loginName1");
        employee.setFirstName("firstName1");
        employee.setLastName("lastName1");
        employee.setTitle("title1");
        employee.setPassword("password1");
        employee.setAddress(new Address("city1", "street1", "zip1"));
        employee.setRoleList(new HashSet<>());
        employee.getRoleList().add(em.find(Role.class, 1L));
        employee.setDepartment(em.find(Department.class, 1L));
        em.persist(employee);
        em.getTransaction().commit();

        em.getTransaction().begin();
        employee = new Employee();
        employee.setLoginName("loginName2");
        employee.setFirstName("firstName2");
        employee.setLastName("lastName2");
        employee.setTitle("title2");
        employee.setPassword("password2");
        employee.setAddress(new Address("city1", "street1", "zip1"));
        employee.setBoss(em.find(Employee.class, 1L));
        employee.setRoleList(new HashSet<>());
        employee.getRoleList().add(em.find(Role.class, 2L));
        employee.setDepartment(em.find(Department.class, 2L));
        em.persist(employee);
        em.getTransaction().commit();
    }

    private static void createDepartment(EntityManagerFactory factory) {
        EntityManager em = factory.createEntityManager();
        em.getTransaction().begin();
        Department department = new Department();
        department.setName("dep1");
        em.persist(department);

        department = new Department();
        department.setName("dep2");
        em.persist(department);
        em.getTransaction().commit();

    }

    private static void createProject(EntityManagerFactory factory) {
        EntityManager em = factory.createEntityManager();
        em.getTransaction().begin();
        Project project = new Project();
        project.setName("proj1");
        project.setFromDate(new Date(new Date().getTime() - 10 * 24 * 60 * 1000));
        project.setFromDate(new Date(new Date().getTime() + 10 * 24 * 60 * 1000));
        project.setOwner(em.find(Employee.class, 1L));
        project.setTaskList(new HashSet<>());
        Task task = new Task();
        task.setName("task1");
        task.setParticipant(em.find(Employee.class, 2L));
        project.getTaskList().add(task);
        em.persist(project);
        em.getTransaction().commit();

    }

    private static void createRole(EntityManagerFactory factory) {
        EntityManager em = factory.createEntityManager();
        em.getTransaction().begin();
        Role role = new Role();
        role.setName("role1");
        em.persist(role);

        role = new Role();
        role.setName("role2");
        em.persist(role);
        em.getTransaction().commit();

    }

}
