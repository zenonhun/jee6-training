/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.domain.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author avincze
 */
@Entity
@Table(name = "IqjbLog")
public class IqjbLog extends IqjbEntity{

    private String logMessage;
    private String executionTime;
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

    public String getLogMessage() {
        return logMessage;
    }

    public void setLogMessage(String logMessage) {
        this.logMessage = logMessage;
    }

    public String getExecutionTime() {
        return executionTime;
    }

    public void setExecutionTime(String executionTime) {
        this.executionTime = executionTime;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    
    
    
    @Override
    public String toString() {
        return "hu.iqjb.domain.model.IqjbLog[ id=" + id + " ]";
    }
    
}
