/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.iqjb.repository;

import hu.iqjb.domain.model.Department;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author avincze
 */
@Stateless
@LocalBean
public class DepartmentRepository {

    @PersistenceContext(unitName = "server1PU")
    private EntityManager em;
   
    
    public void add(Department entity){
        em.persist(entity);
        System.out.println("called");
    }
    
    public List<Department> getAll(){
        return em.createQuery("select d from Department d", 
                Department.class)
                .getResultList();
    }
}
